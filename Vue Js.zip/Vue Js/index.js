 var one = new Vue({
    el:"#vue-app-one",
    data : {
  title : "this is the first vue instance"
    },
    methods : {

    },
    computed : {
       greet : function() {
        return("Hello from app one");
       }
    }
});
 var two = new Vue({
    el:"#vue-app-two",
    data : {
title : "this is the second vue instance"
    },
    methods : {
 changeTitle : function(){
        one.title = "Title Changed"
       }
    },
    computed : {
  greet : function() {
        return("Hello from app two");
       }

    }
});
 two.title ="Title Changed From Outside";