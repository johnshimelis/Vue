 var vm = new Vue({
    el:"#vue-app",
    data : {
        //message : "john",
        job : "Student",
        website : "http://www.youtube.com/johnshimelis",
        myName : '<h1>My name is Yohannes</h1>',
        age : 22,
        x : 0,
        y : 0,
        name : "",
        ages : "",
        a : 0,
        b : 0,
        avaliable : false,
        nearby : false,
        error : false,
        success : false,  
        health : 100,
        ended : false,  
        message: 'Hello Vue.js!',

        names : ['john','belay','kaleb','estifo'],

        CV : [
           {name : 'john', age : 22},
           {name : 'kaleb', age : 21},
           {name : 'belay', age : 20},
           {name : 'estifo', age : 19}
           ] ,
           countdown : [] ,
           counter : 10,
           animals : ["cat","dog","bird"],
           sounds : ['meaow','woof','tweet'],
           animalss  :{bird :'tweet', cat:'meaow', dog:'woof'},
           worlds : ['Terran', 'L24-D', 'Ares', 'New Kroy', 'Sebek', 'Vestra']
           


    },
    methods : {
          punch : function(){
                this.health -= 10;
                if(this.health <= 0){
                    this.ended = true;
                }
            },

            restart : function(){
                this.health = 100;
                this.ended = false;
            },
        greet : function(){
            return "Welcome to Vue"
        },
            add : function(inc){
                this.age += inc;
            },
            subtract : function(dec){
                this.age -= dec;
            },
            updateXY : function(event){
                this.x = event.offsetX;
                this.y = event.offsetY;
            },
            click : function(){
                alert("You clicked my youtube channel link");
            },
            logName :function(){
                console.log("You Entered Your Name");
            },
            logAge : function(){
                console.log("You Entered Yor Age");
            }
           
        },
        computed : {
                AddToA : function(){
                 console.log("addToA");
                return this.a + this.age;
               
            },
            AddToB : function(){
                 console.log("addToB");
                return this.b + this.age;
               
            },
            compClasses : function(){
                return{
                    avaliable : this.avaliable,
                    nearby : this.nearby
                }
            },

           

        }
    
});